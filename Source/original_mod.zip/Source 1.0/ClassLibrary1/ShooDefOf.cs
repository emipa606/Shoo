﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using Verse;

namespace Shoo
{
    [DefOf]
    class ShooDefOf
    {
        public static DesignationDef Shoo;

        public static JobDef ShooJob;

        public static JobDef FleeBecauseShoo;
    }
}
